#include <stdio.h>

		/* test problem with unsigned divide */
void
main(void)
{
	unsigned int i;
	unsigned int base;

	i = 0x0f;
	base = 16;

	i = i/base;
	if(i !=0)
		puts("unsigned div fails");
	else
		puts("unsigned div. passes");
}