/*

   STRING.C

*/

#include "itoa.c"
#include "itos.c"
#include "strcpy.c"
#include "strtok.c"
