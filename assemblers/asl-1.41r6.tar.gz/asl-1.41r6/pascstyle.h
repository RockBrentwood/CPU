#define BEGIN {
#define END }

#define AND &&
#define OR ||
#define NOT !

#ifndef False
#define False 0
#define True 1
#endif

#define Nil NULL

#define Ord(b) ((b)?1L:0L)

#define MaxLongInt 2147483647
