#include <stdio.h>

#define SMALL_CONST 3

/*	bug2.c demonstrates the problem with unsigned char promotion to int */

void
main(void)
{
   unsigned char ucChar = SMALL_CONST;
   int iInt;
   int iInt2 = 0xffff;    /* force accA to have something in it */

	iInt = ucChar;			/* should promote to int, iInt == SMALL_CONST */
	iInt2 = SMALL_CONST;
   if ((iInt) != (iInt2))
		puts("unsigned char promotion Fails.");
   else
		puts("unsigned char promotion Passes.");
printf("this is a test %d\n", 485);

}

