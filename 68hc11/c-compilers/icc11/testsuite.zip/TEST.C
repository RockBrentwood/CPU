#include <stdio.h>

			/* tests unsigned int modulo */
void
main(void)
{
	unsigned int rem = 0xffff;

	rem = rem % 16;
	if ( rem != 0xf)
		puts("Failed");
	else
		puts("Passed");
}
