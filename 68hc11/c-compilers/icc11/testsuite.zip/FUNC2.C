f1(a){return a& 0xff00;}
f2(a){return a&~0xff00;}
f3(a){return a& 0x00ff;}
f4(a){return a&~0x00ff;}
f5(a){return a& 0xffff;}
f6(a){return a&~0xffff;}

main ()
{
  int a = 0xCDEF;

  if (f1(a)!=0xCD00||
      f2(a)!=0x00EF||
      f3(a)!=0x00EF||
      f4(a)!=0xCD00||
      f5(a)!=0xCDEF||
      f6(a)!=0x0000)
    puts("Fail\a");
  else
	 puts("Pass");
}
