#include <stdio.h>

char cChar;
unsigned char ucChar;
short int  iInt;
unsigned short int uInt;

void
main(void)
{
    char lcChar = 0x7f;
    unsigned char lucChar = 0xff;
    int  liInt = 0xfffe;
    unsigned int luInt = 0xfffe;

    cChar = 1;
    ucChar = 1;
    iInt = 1;
    uInt = 1;

    lcChar &= ~cChar;
    if (lcChar != 0x7e)
        puts("Fail char\a");

    lucChar &= ~ucChar;
    if (lucChar != 0xfe)
        puts("Fail uchar\a");

    liInt = liInt & ~iInt;
    if (liInt != 0xfffe)
        puts("Fail int\a");

    luInt &= ~uInt;
    if (luInt != 0xfffe)
        puts("Fail uint\a");

}