f(short a,short b){return a/b;}
main(){if(f(-32768,-1)!=32768)puts("Fail\a");else return;}
