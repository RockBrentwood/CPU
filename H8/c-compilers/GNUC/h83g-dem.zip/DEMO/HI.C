#include <stdio.h>

fact(x)
{
  if (x > 1) return (x*(fact(x-1)));
  return 1;
}
main()
{
        int i;
        for (i = 1; i < 5; i++)
                iprintf("Hello World %d\n",fact(i));
}
