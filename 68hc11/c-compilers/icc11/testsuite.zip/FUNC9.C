#include <stdio.h>

unsigned char ucChar;
unsigned short int uInt;

void
main(void)
{
    unsigned char lucChar = 0xff;
    unsigned int luInt = 0xfffe;

    ucChar = 1;
    uInt = 1;

    lucChar &= ~ucChar;
    if (lucChar != 0xfe)
    {
        puts("Fail uchar\a");
		printf(" result = %x\n", lucChar);
    }

    luInt &= ~uInt;
    if (luInt != 0xfffe)
        puts("Fail uint\a");

}