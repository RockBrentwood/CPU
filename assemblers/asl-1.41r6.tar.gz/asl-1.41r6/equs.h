/* equs.asm-Includefile f�r C-Programm */
#define SEGTEST 0x157 /*  Kommentar kommt mit */
#define FTEST 0.52359877559829893
#define STEST "Hello World"
#define UTEST 0x1
/* Ende Includefile f�r C-Programm */
