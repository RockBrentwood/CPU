int l[]={0,1};
main(){int*p=l;switch(*p++){case 0:puts("Pass"); return;case 1:break;case 2:break;case 3:case 4:break;}puts("Fail\a");}
