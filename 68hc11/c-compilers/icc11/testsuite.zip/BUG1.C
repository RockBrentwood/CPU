#include <stdio.h>

/*	bug1.c demonstrates the problem with unary minus */

void
main(void)
{
   int uint = 1;
   
   if ((-uint) != (-1*uint))
		printf("Unary Minus Fails\n\n");
   else
		printf("unary Minus Passes\n\n");
}

