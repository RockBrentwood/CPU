#include <stdio.h>


void
main(void)
{
	char cChar;
	unsigned char ucChar;
	short int  iInt;
	unsigned short int uInt;
    
	 char lcChar = 0x70;
    unsigned char lucChar = 0xf0;
    int  liInt = 0xf000;
    unsigned int luInt = 0xf000;

    cChar = 1;
    ucChar = 1;
    iInt = 1;
    uInt = 1;

    lcChar |= cChar;
    if (lcChar != 0x71)
        puts("Fail char\a");

    lucChar |= ucChar;
    if (lucChar != 0xf1)
        puts("Fail uchar\a");

    liInt = liInt | iInt;
    if (liInt != 0xf001)
        puts("Fail int\a");

    luInt |= uInt;
    if (luInt != 0xf001)
        puts("Fail uint\a");

}
