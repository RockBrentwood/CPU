#include <stdio.h>

void
main(void)
{
	unsigned char speed = 50;

	if((100 - speed) != 50)
		puts("const char subtract fials!");
	else
		puts("const char subtract passes!");
}	