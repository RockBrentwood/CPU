typedef struct {int dims[1]; } *A;

f(unsigned obj)
{  
  unsigned char y = obj >> 8;
  y &= ~4;

  if ((y==0)||(y!=251  ))
    puts("Fail\a");

  if(((int)obj&7)!=7)return;

  REST_OF_CODE_JUST_HERE_TO_TRIGGER_THE_BUG:

  {
    unsigned char t = obj >> 24;
    if (!(t==0)&&(t<=0x03))
      return 0;
    return ((A)(obj&0x00FF))->dims[1];
  }
}

g(){return 0xff00;}
main (){int x;f(g());return;}
