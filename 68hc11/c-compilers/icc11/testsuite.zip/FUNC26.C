unsigned*
f(p)unsigned*p;
{
  unsigned a = (*p++) >> 8;
  return p + a;
}

main ()
{
  unsigned x = 0x8000;
  if (f(&x) != &x + 0x81)
    puts("Fail\a");
  return;
}
