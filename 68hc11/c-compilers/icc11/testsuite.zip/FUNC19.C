static fu (unsigned short data)
{
  return data;
}
ru(i)
{
   if(fu(i++)!=5)puts("Fail\a");
   if(fu(++i)!=7)puts("Fail\a");
}
static fs (signed short data)
{
  return data;
}
rs(i)
{
   if(fs(i++)!=5)puts("Fail\a");
   if(fs(++i)!=7)puts("Fail\a");
}


main()
{
  ru(5);
  rs(5);
  return;
}
