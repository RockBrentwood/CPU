main()
{
int j=1081;
struct
{
int m:11;
}l;
if((l.m=j)==j)puts("Fail\a");

}
