f(got){if(got!=0xffff)puts("Fail\a");}
main(){signed char c=-1;unsigned u=(unsigned short)c;f(u);return;}
