int
f(long x)
{
  x >>= 8;
  return x & 0xff;
}

main()
{
  if (f(0xCDEF) != 0xCD)
    puts("Fail\a");
  
}
