main ()
{
  unsigned long val = 1;

  if (val > (unsigned long) ~0)
    puts("Fail\a");
  
}
