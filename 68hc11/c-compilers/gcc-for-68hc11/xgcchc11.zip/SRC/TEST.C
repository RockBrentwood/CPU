
#include "dmd.h"
#include "os.h"
#include "string.h"

word rti_sub_counter;
word rti_counter;
char rti_str[6];

/* interrupt function (no interrupt-pragma needed) */
void rti_interrupt(void)
{
   rti_sub_counter++;
   if ( rti_sub_counter == 122 )
   {
      rti_sub_counter = 0;
      rti_counter++;
      dmd_Home();
      dmd_ShowString(itos(rti_counter, rti_str, 5));
   }
}

void main(void)
{
   rti_sub_counter = 0;
   rti_counter = 0;

   /* *(byte *)0x07fa0 = 0; */

   dmd_Init((byte *)0x07f80);       /* Baseadress of Dot Matrix Display */
   dmd_ShowString("GNU C System");

   os_set_irq(OS_IRQ_RTI, rti_interrupt);
}
