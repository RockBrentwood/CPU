f(a){return (--a > 0);}
main(){if(f(0x8000)==0)puts("Fail\a");return;}
