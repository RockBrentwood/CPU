x()
{
	signed char c=-1;
	return c<0;
}
main()
{
	if(x()!=1)
		puts("Fail\a");
	else
		puts("Pass");	
}
