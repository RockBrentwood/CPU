#ifdef __cplusplus
extern "C" {
#endif
#include <sys/signal.h>
#ifdef __cplusplus
}
#endif
